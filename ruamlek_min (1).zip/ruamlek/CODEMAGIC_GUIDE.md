# คู่มือ Codemagic (ทำบนมือถือ)
1) สมัคร/ล็อกอิน Codemagic.io → เลือก **Build from .zip**
2) อัปโหลดไฟล์ `ruamlek_min.zip`
3) เลือก Project type = **Flutter**, Platform = **Android**, Output = **APK**
4) Start build → รอเสร็จ → ดาวน์โหลด `app-release.apk` ในแท็บ Artifacts
5) เปิดไฟล์ APK เพื่อติดตั้งในเครื่อง (อนุญาต Unknown sources ถ้าระบบถาม)
